
# Zyura Store - Static Payment Page

Files included:
- index.html  (halaman utama)
- logo.png    (logo teks)
- qrcode.png  (placeholder — **ganti** dengan QR yang kamu punya)
- README.md

**Langkah cepat deploy ke GitHub & Vercel (dari HP)**
1. Buka repo GitHub kamu, klik **Add file → Upload files**.
2. Upload semua file dalam zip: `index.html`, `logo.png`, **dan** file QR as `qrcode.png` (ganti file placeholder jika perlu).
3. Commit changes.
4. Buka Vercel → New Project → Connect GitHub → pilih repo kamu → Import → Deploy.

Notes:
- Jika nomor WhatsApp berbeda format, ubah variabel `phone` pada index.html.
- QR harus dinamai `qrcode.png` dan berada di root repo.
